## 笔试说明

1. 请根据下面的题目说明在限定时间内完成 `src/exams/` 目录中的题目
2. 每道题目都有运行结果，仅供你参考
3. 请写好必要的注释
4. 你的代码应该写在 `index.vue` 或者 `index.js` 文件中

## 启动项目和调试

```bash
npm i # 安装依赖
npm run dev # 启动 dev server
```
