<!-- 第二题 -->
<template>
  <div className="model">
    <div>待实现</div>
  </div>
</template>

<script lang="ts">
import { h } from 'vue';

/**
 * 测试数据
 */
const model = {
    title: '测试',
    confirm: '确认',
    cancel: '取消'
};

const Model = {
  props: ['title', 'confirm', 'cancel'],
  components: {},
};

export default Model;

/**
 * 以下为测试用例，无需修改
 */
Model.__test__ = () =>
  h(Model, { ...model })
</script>

<style lang="less">
.model {
  background-color: #fff0f1;
  height: 1.36rem;
  width: 4.3rem;
  margin: 0 auto;
  margin-bottom: 0.1rem;
}

html {
  font-size: 60px;
}
</style>
