### 目标

使用 Vue, <strong style="color:#FF0000;">参考下述需求优先级和设计稿</strong>，实现弹窗组件，禁止使用三方组件。

### 关键需求点

- **功能1:** 实现弹窗及蒙版
  - 点击按钮后弹出弹窗及蒙层
- **功能2:** 添加确定及关闭按钮
  - 点击确定打印console “弹窗确认”
  - 点击确定及右上角×关闭

### 设计稿

<p style="text-align:center;">
  <img
    src="https://mdn.alipayobjects.com/huamei_r9lmnz/afts/img/A*NA3VQ7B4DBwAAAAAAAAAAAAADpp5AQ/original"
    style="width:80%;max-width:500px;"
  />
  <br />
  <a href="https://mdn.alipayobjects.com/huamei_r9lmnz/afts/img/A*NA3VQ7B4DBwAAAAAAAAAAAAADpp5AQ/original" target="_blank">
    点击查看设计稿原图
  </a>
</p>
