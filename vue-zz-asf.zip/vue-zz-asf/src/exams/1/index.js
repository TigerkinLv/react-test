/**
 * 第一题
 */
import { isEqual } from 'lodash-es';

function findSameNumberSum(a) {
  // write your code here ...
  return [];
}
 /**
  * 以下为测试用例，无需修改
  */
 export default () => {
  try {
    if (!isEqual(findSameNumberSum(['a', 'b', 3, 1, 'v', 'v', 2, 'e', 2, 1]).sort(), [
      2,
      3,
      4,
      'a',
      'b',
      'e',
      'v',
      'v',
    ])) {
      throw new Error('Wrong answer');
    }
    if (!isEqual(findSameNumberSum([1, 11, 111, 1, 22, 222, 3, 11, 444]).sort(), [
      111,
      2,
      222,
      3,
      44,
      444,
    ])) {
      throw new Error('Wrong answer');
    }
    console.log('通过');
    return true;
  } catch (err) {
    console.error(err);
    console.log('不通过');
    return false;
  }
 };
