/**
 * 第三题
 */
const A = () => Promise.resolve('a'); // a 请求
const B = a => Promise.resolve('ab'); // b 请求
const C = () => Promise.resolve('bc'); // c 请求

function batch() {
  // write your code here ...
  return [];
}

/**
 * 以下为测试用例，无需修改
 */
export default async () => {
  try {
    const [b, c] = await batch();
    if (b !== 'ab') {
      throw new Error('Wrong answer');
    }
    if (c !== 'bc') {
      throw new Error('Wrong answer');
    }
    console.log('通过');
    return true;
  } catch (err) {
    console.error(err);
    console.log('不通过');
    return false;
  }
};
