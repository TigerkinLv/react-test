/**
 * 第四题
 */
function findNode() {
  // write your code here ...
  return [];
}

/**
 * 以下为测试用例，无需修改
 */
export default () => {
  try {
    const [nodeTag, divCount] = findNode();
    if (
      nodeTag !==
      new Set([...document.querySelectorAll('*')].map(e => e.tagName)).size
    ) {
      throw new Error('Wrong answer');
    }
    if (divCount !== new Set([...document.querySelectorAll('div')]).size) {
      throw new Error('Wrong answer');
    }
    console.log('通过');
    return true;
  } catch (err) {
    console.error(err);
    console.log('不通过');
    return false;
  }
};
